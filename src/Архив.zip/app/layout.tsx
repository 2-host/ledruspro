// src/app/layout.tsx
import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'LEDRUS PRO',
  description: 'Каталог исполнителей — Next.js + SQLite/Prisma',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ru">
      <head>
        {/* Bootstrap CSS + иконки */}
        <link
          rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        />
        <link
          rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css"
        />
      </head>
      <body>
        {/* === NAVBAR === */}
        <nav className="navbar navbar-expand-lg sticky-top bg-white border-bottom">
          <div className="container py-2">
            <a className="navbar-brand fw-semibold" href="/">
              <i className="bi bi-stars me-2 text-primary"></i>LEDRUS PRO
            </a>

            <button
              className="navbar-toggler"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#nav"
              aria-controls="nav"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span className="navbar-toggler-icon"></span>
            </button>

            <div className="collapse navbar-collapse" id="nav">
              <ul className="navbar-nav ms-auto align-items-lg-center">
                <li className="nav-item me-lg-3">
                  <a className="nav-link link-muted" href="/c/all">Исполнители</a>
                </li>
                <li className="nav-item">
                  <a className="btn btn-primary" href="/provider/new">
                    <i className="bi bi-building-add me-1"></i> Стать исполнителем
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </nav>

        {/* Контент страниц */}
        <main className="py-4">{children}</main>

        {/* === FOOTER === */}
        <footer className="py-4 bg-white border-top">
          <div className="container">
            <div className="row g-3 align-items-center">
              <div className="col-md">
                <a className="navbar-brand fw-semibold" href="/">
                  <i className="bi bi-stars me-2 text-primary"></i>LEDRUS PRO
                </a>
                <div className="small text-secondary">© 2025. Все права защищены.</div>
              </div>
              <div className="col-md-auto">
                <ul className="nav small">
                  <li className="nav-item"><a className="nav-link link-muted" href="#">Пользовательское соглашение</a></li>
                  <li className="nav-item"><a className="nav-link link-muted" href="#">Политика конфиденциальности</a></li>
                  <li className="nav-item"><a className="nav-link link-muted" href="#">Контакты</a></li>
                </ul>
              </div>
            </div>
          </div>
        </footer>

        {/* Bootstrap JS (для бургера и др.) */}
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" />
      </body>
    </html>
  );
}
